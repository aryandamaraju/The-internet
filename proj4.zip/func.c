
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

void print(char *messageArr[]){
    // Print out the messages
    for(int i = 0; i < 10; i++){
        printf("Message[%d]: %s \n", i, messageArr[i]);
    }
    printf("\n");
}

void weave(char* str) {
    int len = strlen(str);
    char temp;
    int count = 0;
    while ((count + 2) < len){  //1234567
      temp = str[count];        //t=2
      str[count] = str[count + 2];    //str[1]= 4
      str[count+2] = temp;          //str[3] = 2
      count += 1;
      if(count % 2 == 0){
        count += 2;
      }
    }
}

int read(char *Arr[], int index){
    char original[] = "This is the original message.";

    printf("Enter new message: ");

    // Set up variables
    int buffer = 256;
    int position = 0;

    // Allocate memory for the string
    char *str = malloc(sizeof(char) * buffer);

    int ch;
    int cont = 1;

    // Read in the string
    while(cont){
        ch = fgetc(stdin);

        // If we hit the end of the file or a new line, stop reading
        if(ch == EOF || ch == '\n'){
            str[position] = '\0';
            cont = 0;
        }

        // Else, add the character to the string
        else{
            str[position] = ch;
        }

        // If we need more memory, allocate more
        if(position >= buffer){
            buffer += 256;
            str = realloc(str, buffer);
        }

        position++;
    }
    // Check if the message is valid
    if(isupper(str[0])){
        if(str[position - 2] == '.' || 
    str[position - 2] == '!' || 
    str[position - 2] == '?'){
            // If already allocated, free the memory
            if (strcmp(Arr[index], original) != 0){
                free(Arr[index]);
            }
            // If the message is valid, save it
            Arr[index] = str;
            printf("\n");
            return 1;
        }
    }
    // If the message is invalid
    printf("invalid message, keeping current\n\n");
    free(str);
    return 0;
}

void statistics(char* array[]) {
    int location;
    printf("What string do you want to see?: ");
    scanf("%d", &location);

    if (location < 0 || location > 9) {
        printf("Invalid input. Please try again.\n");
        return;
    }

    int len = strlen(array[location]);
    int letters = 0;
    int digits = 0;
    int special = 0;
    int punctuation = 0;

    for (int i = 0; i < len; i++) {
        if (isalpha(array[location][i])) {
            letters++;
        } else if (isdigit(array[location][i])) {
            digits++;
        } else if (ispunct(array[location][i])) {
            punctuation++;
        } else if (isspace(array[location][i])) {
            continue;
        } else {
            special++;
        }
    }

    printf("There are a total of %d characters in the text.\n", len);
    printf("There are %d letters.\n", letters);
    printf("There are %d digits.\n", digits);
    printf("There are %d special characters.\n", special);
    printf("There are %d punctuation characters.\n", punctuation);
}

void Free(char *messageArr[]){
    char original[] = "This is the original message.";
    for(int i = 0; i < 10; i++){
        if (strcmp(messageArr[i], original) != 0){
            free(messageArr[i]);
        }
    }
}